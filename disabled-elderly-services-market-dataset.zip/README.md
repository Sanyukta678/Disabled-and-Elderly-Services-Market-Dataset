# Disabled and Elderly Services Market — Dataset

This dataset contains structured metadata and summaries derived from the public landing page of the Disabled & Elderly Services Market report (HC3565) by Next Move Strategy Consulting.

Includes:
- metadata.json
- summary.txt
- segments.csv
- companies.csv
- table_of_contents.md
- license.txt

This dataset contains only publicly accessible information and excludes all paid report contents.
